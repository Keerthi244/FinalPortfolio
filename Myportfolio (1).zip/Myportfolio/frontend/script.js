particlesJS("particles-js", {
  particles: {
    number: { value: 150 },
    color: { value: "#B0E0E6" },
	shape: { type: "star", sides: 5 } ,
    opacity: { value: 0.9 },
    size: { value: 3},
    line_linked: {
      enable: true,
      distance: 180,
      color: "#00ffff",
      opacity: 0.4,
      width: 1
    },
    move: {
      enable: true,
      speed: 2,
      direction: "none",
      random: false,
      out_mode: "out"
    }
  },
  interactivity: {
    events: {
      onhover: { enable: true, mode: "repulse" },
      onclick: { enable: true, mode: "push" }
    },
    modes: {
      repulse: { distance: 100 },
      push: { particles_nb: 4 }
    }
  },
  retina_detect: true
});
